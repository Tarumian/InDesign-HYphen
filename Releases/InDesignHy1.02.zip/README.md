﻿# Adobe InDesign Հայերեն Տողադարձման Տեղադրիչ

ԻՆՉՊԵՍ ՏԵՂԱԴՐԵԼ.

1. Փակեք Adobe InDesign-ը (եթե բաց է):
2. Երկու անգամ կտտացրեք "install.bat" նիշքի վրա:
3. Թույլատրեք վարիչի հարցումը (UAC -> Yes):
4. Տեղադրիչը ինքանբար կտեղադրի հայերեն տողադարձման բառարանը:

ԻՆՉՊԵՍ ՕԳՏԱԳՈՐԾԵԼ INDESIGN-ՈՒՄ.

1. Բացեք Adobe InDesign-ը:
2. Գնացեք Edit -> Preferences -> Dictionary (կամ Ctrl + K -> Dictionary):
3. Language ցանկից ընտրեք "Armenian" (կամ "Armenian (Armenia)"):
4. Hyphenation բաժնում ստուգեք, որ ընտրված լինի "Hunspell":
5. Գրվածքը նշեք, Character վահանակում լեզուն դրեք "Armenian", իսկ Paragraph վահանակում միացրեք "Hyphenate" նշիչը:

ՀԵՌԱՑՆԵԼՈՒ ՀԱՄԱՐ.
Աշխատեցրեք "uninstall.bat" նիշքը:

